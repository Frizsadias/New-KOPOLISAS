<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Bootstrap, Landing page, Template, Business, Service">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="author" content="Grayrids">
    <title>KOPOLISAS</title>
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="img/kopolisas.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/LineIcons.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/nivo-lightbox.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/responsive.css">

</head>

<body>

    <!-- Header Section Start -->
    <header id="about" class="hero-area">
        <div class="overlay">
            <span></span>
            <span></span>
        </div>
        <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
            <div class="container">
                <a href="index.html" class="navbar-brand"><img src="img/logoo.png" alt=""></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse"
                    aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="lni-menu"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav mr-auto w-100 justify-content-end">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#about">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="services.php">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="gallery.php">Gallery</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="team.php">Team</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-singin" href="kopolisas/kopolisas/login.php">LOGIN</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <div class="row space-100">
                <div class="col-lg-6 col-md-12 col-xs-12">
                    <div class="contents">
                        <h2 class="head-title">About KOPOLISAS</h2>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-xs-12 p-0">
                    <div class="intro-img">
                        <img src="img/about-removebg-preview.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Section End -->


    <!-- Services Section Start -->
    <section id="services" class="section">
        <div class="container">

            <div class="row">
                <!-- Start Col -->
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <a href="https://www.facebook.com/koperasipolitekniksultanhajiahmadshahkuantanberhad">
                        <div class="services-item text-center">
                            <div class="icon">
                                <i class="lni-facebook"></i>
                            </div>
                            <h4>Facebook KOPOLISAS</h4>
                            <p>Get the latest KOPOLISAS information on KOPOLISAS official Facebook.</p>
                        </div>
                    </a>
                </div>
                <!-- End Col -->
                <!-- Start Col -->
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <a href="document/agm31.pdf">
                        <div class="services-item text-center">
                            <div class="icon">
                                <i class="lni-bookmark"></i>
                            </div>
                            <h4>AGM KOPOLISAS</h4>
                            <p>Annual General Meeting or Information about the 31st KOPOLISAS Meeting.</p>
                        </div>
                </div>
                <!-- End Col -->
                <!-- Start Col -->
                <div class="col-lg-4 col-md-6 col-xs-12">
                    <a href="member_benefit.php">
                        <div class="services-item text-center">
                            <div class="icon">
                                <i class="lni-users"></i>
                            </div>
                            <h4>Member benefits</h4>
                            <p>Various benefits and advantages that members KOPOLISAS have.</p>
                        </div>
                    </a>
                </div>
                <!-- End Col -->

            </div>
        </div>
    </section>
    <!-- Services Section End -->



    <!-- VISI -->
    <section id="business-plan">
        <div class="container">

            <div class="row">
                <!-- Start Col -->
                <div class="col-lg-6 col-md-12 pl-0 pt-70 pr-5">
                    <div class="business-item-img">
                        <img src="img/visi.png" class="img-fluid" alt="">
                    </div>
                </div>
                <!-- End Col -->
                <!-- Start Col -->
                <div class="col-lg-6 col-md-12 pl-4">
                    <div class="business-item-info">
                        <h3>Vision Koperasi Politeknik Sultan Haji Ahmad Shah</h3>
                        <p>​Providing excellent service to members without favoritism and compromise in an effort to
                            improve the socio-economic status and welfare of members.</p>
                    </div>
                </div>
                <!-- End Col -->

            </div>
        </div>
    </section>
    <!-- Business Plan Section End -->

    <!-- MISI -->
    <section id="business-plan">
        <div class="container">

            <div class="row">
                <!-- Start Col -->
                <div class="col-lg-6 col-md-12 pl-0 pt-70 pr-5">
                    <div class="business-item-info">
                        <h3>Mission Koperasi Politeknik Sultan Haji Ahmad Shah</h3>
                        <p>Making Kuantan Polisas Berhad the most advanced and best in Polytechnic by emphasizing on
                            meeting the needs and goals of its members based on Islamic principles and values.</p>
                    </div>
                </div>
                <!-- End Col -->
                <!-- Start Col -->
                <div class="col-lg-6 col-md-12 pl-4">
                    <div class="business-item-img">
                        <img src="img/misi.png" class="img-fluid" alt="">
                    </div>
                </div>
                <!-- End Col -->

            </div>
        </div>
    </section>
    <!-- Business Plan Section End -->

    <!-- FILSAFAH -->
    <section id="business-plan">
        <div class="container">

            <div class="row">
                <!-- Start Col -->
                <div class="col-lg-6 col-md-12 pl-0 pt-70 pr-5">
                    <div class="business-item-img">
                        <img src="img/filosofi.png" class="img-fluid" alt="">
                    </div>
                </div>
                <!-- End Col -->
                <!-- Start Col -->
                <div class="col-lg-6 col-md-12 pl-4">
                    <div class="business-item-info">
                        <h3>Philosophy Koperasi Politeknik Sultan Haji Ahmad Shah</h3>
                        <p>Purifying the Cooperative movement to increase the benefits to members and the community
                            based on Cooperative values ​​according to the pleasure of Allah S.W.T</p>
                    </div>
                </div>
                <!-- End Col -->

            </div>
        </div>
    </section>
    <!-- Business Plan Section End -->

    <section id="showcase">
        <div class="container-fluid right-position">
            <!-- Start Row -->
            <div class="row gradient-bg">
                <div class="col-lg-12">
                    <div class="showcase-text section-header text-center">
                        <div>
                            <h2 class="section-title">History Of Koperasi Politeknik Sultan Haji Ahmad Shah</h2>
                            <br>
                            <div class="desc-text">
                                <p>Sultan Haji Ahmad Shah Polytechnic Cooperative, Malaysia was established on July 18,
                                    1989 (Registration No.: KOOP.INST.NO.46) <br>
                                    a total of 108 members and continues to increase until now the number of cooperative
                                    members has reached 7,606 members.<br>
                                    The initial establishment of this cooperative aimed to meet the needs of students
                                    during the orientation period <br>
                                    and continued to grow until it was able to establish several retail businesses such
                                    as barber shop, laundry, mini post office, and others.</p>
                            </div>

                            <div>
                                <br>
                                <br>
                                <h2 class="section-title">Growth Objectives Koperasi Politeknik Sultan Haji Ahmad Shah
                                </h2>
                                <br>
                                <div class="big">
                                    <p>1. Increase the type and amount of sales of goods and services needed by members,
                                        campus residents and the general public. <br>
                                        2. Increase financial returns in the form of dividends, bonuses, rebates and
                                        discounts at a rate that is satisfactory to members. <br>
                                        3. Increase the benefits of charitable welfare protection/insurance for free to
                                        members and members' families. <br>
                                        4. Improve education and training programs for management and business skills
                                        for free/subsidized to members. <br>
                                        5. Increase motivational programs and academic programs with free subsidies to
                                        member families. <br>
                                        6. Increase the value of appropriate donations/donations/gifts/welfare aid to
                                        members, members' families, campus residents, the Polytechnic and the community.
                                        <br>
                                        7. Increase real estate and business development projects to stimulate economic
                                        activity for cooperatives and the country. <br>
                                        8. Increase the return of control in the form of rent and premium to the
                                        Polytechnic. <br>
                                        9. Transferring most of the responsibilities of the Polytechnic to maintain and
                                        improve the well-being and harmony of staff families.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Row -->

  <!-- Footer Section Start -->
  <footer>
    <!-- Footer Area Start -->
    <section id="footer-Content">
      <div class="container">
        <!-- Start Row -->
        <div class="row">
          <!-- Start Col -->
          <div class="col-lg-3 col-md-6 col-sm-6 col-xs-6 col-mb-12">
            <div class="footer-logo">
              <img src="img/logoo.png" alt="" />
            </div>
          </div>
          <!-- End Col -->
          <!-- Start Col -->
          <div class="col-lg-2 col-md-6 col-sm-6 col-xs-6 col-mb-12">
            <div class="widget">
              <h3 class="block-title">Quick Access</h3>
              <ul class="menu">
                <li><a href="about.php"> - About Us</a></li>
                <li><a href="services.php">- Services</a></li>
                <li><a href="gallery.php">- Gallery</a></li>
                <li><a href="team.php">- Team</a></li>
                <li><a href="contact.php">- Contact</a></li>
              </ul>
            </div>
          </div>
          <!-- End Col -->
          <!-- Start Col -->
          <div class="col-lg-2 col-md-6 col-sm-6 col-xs-6 col-mb-12">
            <div class="widget">
              <h3 class="block-title">Location</h3>
              <ul class="menu">
                <li><a href="https://www.google.com/maps/place/koperasi+politeknik+sultan+haji+ahmad+shah+kuantan+berhad/@3.8625804,103.3103211,17z/data=!3m1!4b1!4m5!3m4!1s0x31c8bb93a47baa41:0x80542b4e0a7f51b6!8m2!3d3.8625624!4d103.3125153"> - KOPOLISAS</a></li>
              </ul>
            </div>
          </div>
          <!-- End Col -->
          <!-- Start Col -->
          <div class="col-lg-2 col-md-6 col-sm-6 col-xs-6 col-mb-12">
            <div class="widget">
              <h3 class="block-title">Our Social Media</h3>
              <ul class="menu">
                <li><a href="#">
                  <div class="feature-icon float-left">
              <i class="lni-facebook"></i>
            </div> - Facebook</a></li>
            <li><a href="#">
                  <div class="feature-icon float-left">
              <i class="lni-website"></i>
            </div> - Website</a></li>
            <li><a href="#">
                  <div class="feature-icon float-left">
              <i class="lni-envelope"></i>
            </div> - E-mail</a></li>
              </ul>
            </div>
          </div>
          <!-- End Col -->
        </div>
        <!-- End Row -->
      </div>
      <!-- Copyright Start  -->

      <div class="copyright">
        <div class="container">
          <!-- Star Row -->
          <div class="row">
            <div class="col-md-12">
              <div class="site-info text-center">
                  <a href="" rel="nofollow">Copyright © 2022 KOPOLISAS - All rights reserved.</a>
              </div>
            </div>
            <!-- End Col -->
          </div>
          <!-- End Row -->
        </div>
      </div>
      <!-- Copyright End -->
    </section>
    <!-- Footer area End -->
  </footer>
  <!-- Footer Section End -->


    <!-- Go To Top Link -->
    <a href="#" class="back-to-top">
        <i class="lni-chevron-up"></i>
    </a>

    <!-- Preloader -->
    <div id="preloader">
        <div class="loader" id="loader-1"></div>
    </div>
    <!-- End Preloader -->

    <!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="js/jquery-min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.nav.js"></script>
    <script src="js/scrolling-nav.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/nivo-lightbox.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/main.js"></script>

</body>

</html>